getwd()
setwd("C:\\Users\\User\\Desktop\\It24101143_ps")
data<-read.table("DATA 4.txt",header=TRUE,sep=" ")
fix(data)
attach(data)
##part2
boxplot(X1,main="boxplot for team attendance", outline=TRUE,outpch=8,horzontal=TRUE)
boxplot(X1,main="boxplot for team salary", outline=TRUE,outpch=8,horzontal=TRUE)
boxplot(X1,main="boxplot for years", outline=TRUE,outpch=8,horzontal=TRUE)
 
hist(X1,ylab="frequency",xlab="team attendance",main="Histogram for team attendance") 
hist(X2,ylab="frequency",xlab="team salary",main="Histogram for team salary") 
hist(X3,ylab="frequency",xlab="years",main="Histogram for year") 

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X2)
quantile(X3)

IQR(X1)
IQR(X2)
IQR(X3)
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts==max(counts)])
}
get.mode(X3)
table(X3)
max(counts)
counts==max(counts)
counts[counts==max(counts)]
name(counts[counts==max(counts)])

get.outlier<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  IQR<-q3 -q1
  ub<-q3+1.5*IQR
  lb<-q1-1.5*IQR
  print(paste("upper bound= ",ub))
  print(paste("lower bound= ",lb))
  print(paste("outliers: ",paste(sort(z[z<lb|z>ub]),collapse=",")))
}
get.outlier(X1)
get.outlier(X2)
get.outlier(X3)

branch_data<-read.csv("Exercise.txt",header=TRUE,sep=" ")
boxplot(branch_data$sales,main ="box plot for sales",ylab="frequency",xlab="sales")

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outlier <-function(x){
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  IQR<-q3 -q1
  ub<-q3+1.5*IQR
  lb<-q1-1.5*IQR
  
  print(paste("upper bound= ",ub))
  print(paste("lower bound= ",lb))
  print(paste("outliers: ",paste(sort(x[x<lb|x>ub]),collapse=",")))
}
get.outlier(branch_data$year_X3)
str(branch_data)
